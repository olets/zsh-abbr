source ${0:A:h}/tests.zsh
