source ${0:A:h}/zsh-abbr.zsh
